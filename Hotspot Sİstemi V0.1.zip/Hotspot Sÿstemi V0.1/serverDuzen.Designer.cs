﻿namespace Hotspot_Sİstemi_V0._1
{
    partial class serverDuzen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(serverDuzen));
            this.serverAdiGuncelTxt = new System.Windows.Forms.TextBox();
            this.ipAdresGuncelTxt = new System.Windows.Forms.TextBox();
            this.kulAdiGuncelTxt = new System.Windows.Forms.TextBox();
            this.sifreGuncelTxt = new System.Windows.Forms.TextBox();
            this.guncelleBtn = new System.Windows.Forms.Button();
            this.silBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.anaSayfaMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.ServerEkleMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.serverDuzenleMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.yoneticiDuzenleMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.kullaniciAyarMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.cikisMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // serverAdiGuncelTxt
            // 
            this.serverAdiGuncelTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.serverAdiGuncelTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.serverAdiGuncelTxt.ForeColor = System.Drawing.Color.White;
            this.serverAdiGuncelTxt.Location = new System.Drawing.Point(20, 55);
            this.serverAdiGuncelTxt.Name = "serverAdiGuncelTxt";
            this.serverAdiGuncelTxt.Size = new System.Drawing.Size(134, 22);
            this.serverAdiGuncelTxt.TabIndex = 6;
            // 
            // ipAdresGuncelTxt
            // 
            this.ipAdresGuncelTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ipAdresGuncelTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ipAdresGuncelTxt.ForeColor = System.Drawing.Color.White;
            this.ipAdresGuncelTxt.Location = new System.Drawing.Point(20, 108);
            this.ipAdresGuncelTxt.Name = "ipAdresGuncelTxt";
            this.ipAdresGuncelTxt.Size = new System.Drawing.Size(134, 22);
            this.ipAdresGuncelTxt.TabIndex = 7;
            // 
            // kulAdiGuncelTxt
            // 
            this.kulAdiGuncelTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.kulAdiGuncelTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kulAdiGuncelTxt.ForeColor = System.Drawing.Color.White;
            this.kulAdiGuncelTxt.Location = new System.Drawing.Point(20, 168);
            this.kulAdiGuncelTxt.Name = "kulAdiGuncelTxt";
            this.kulAdiGuncelTxt.Size = new System.Drawing.Size(134, 22);
            this.kulAdiGuncelTxt.TabIndex = 8;
            // 
            // sifreGuncelTxt
            // 
            this.sifreGuncelTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sifreGuncelTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifreGuncelTxt.ForeColor = System.Drawing.Color.White;
            this.sifreGuncelTxt.Location = new System.Drawing.Point(20, 223);
            this.sifreGuncelTxt.Name = "sifreGuncelTxt";
            this.sifreGuncelTxt.Size = new System.Drawing.Size(134, 22);
            this.sifreGuncelTxt.TabIndex = 9;
            // 
            // guncelleBtn
            // 
            this.guncelleBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guncelleBtn.Enabled = false;
            this.guncelleBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guncelleBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.guncelleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.guncelleBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.guncelleBtn.ForeColor = System.Drawing.Color.White;
            this.guncelleBtn.Location = new System.Drawing.Point(586, 103);
            this.guncelleBtn.Name = "guncelleBtn";
            this.guncelleBtn.Size = new System.Drawing.Size(104, 42);
            this.guncelleBtn.TabIndex = 10;
            this.guncelleBtn.Text = "GÜNCELLE";
            this.guncelleBtn.UseVisualStyleBackColor = false;
            this.guncelleBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // silBtn
            // 
            this.silBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.silBtn.Enabled = false;
            this.silBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.silBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.silBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.silBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.silBtn.ForeColor = System.Drawing.Color.White;
            this.silBtn.Location = new System.Drawing.Point(586, 182);
            this.silBtn.Name = "silBtn";
            this.silBtn.Size = new System.Drawing.Size(104, 42);
            this.silBtn.TabIndex = 11;
            this.silBtn.Text = "SİL";
            this.silBtn.UseVisualStyleBackColor = false;
            this.silBtn.Click += new System.EventHandler(this.silBtn_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(586, 336);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 42);
            this.button2.TabIndex = 13;
            this.button2.Text = "TEMİZLE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(55, 102);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(185, 276);
            this.listBox1.Sorted = true;
            this.listBox1.TabIndex = 14;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(52, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Server Listesi";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.sifreGuncelTxt);
            this.groupBox1.Controls.Add(this.serverAdiGuncelTxt);
            this.groupBox1.Controls.Add(this.ipAdresGuncelTxt);
            this.groupBox1.Controls.Add(this.kulAdiGuncelTxt);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(290, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 285);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server Düzenle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(17, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 30;
            this.label3.Text = "Şifre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(17, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "Kullanıcı Adı";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(17, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "IP Adres";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(17, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 16);
            this.label12.TabIndex = 27;
            this.label12.Text = "Server Adı";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anaSayfaMenuStrip,
            this.ServerEkleMenuStrip,
            this.serverDuzenleMenuStrip,
            this.yoneticiDuzenleMenuStrip,
            this.kullaniciAyarMenuStrip,
            this.cikisMenuStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(751, 28);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // anaSayfaMenuStrip
            // 
            this.anaSayfaMenuStrip.ForeColor = System.Drawing.Color.White;
            this.anaSayfaMenuStrip.Name = "anaSayfaMenuStrip";
            this.anaSayfaMenuStrip.Size = new System.Drawing.Size(100, 24);
            this.anaSayfaMenuStrip.Text = "ANA SAYFA";
            this.anaSayfaMenuStrip.Click += new System.EventHandler(this.anaSayfaMenuStrip_Click);
            // 
            // ServerEkleMenuStrip
            // 
            this.ServerEkleMenuStrip.ForeColor = System.Drawing.Color.White;
            this.ServerEkleMenuStrip.Name = "ServerEkleMenuStrip";
            this.ServerEkleMenuStrip.Size = new System.Drawing.Size(109, 24);
            this.ServerEkleMenuStrip.Text = "SERVER EKLE";
            this.ServerEkleMenuStrip.Click += new System.EventHandler(this.ServerEkleMenuStrip_Click);
            // 
            // serverDuzenleMenuStrip
            // 
            this.serverDuzenleMenuStrip.ForeColor = System.Drawing.Color.White;
            this.serverDuzenleMenuStrip.Name = "serverDuzenleMenuStrip";
            this.serverDuzenleMenuStrip.Size = new System.Drawing.Size(143, 24);
            this.serverDuzenleMenuStrip.Text = "SERVER DÜZENLE";
            // 
            // yoneticiDuzenleMenuStrip
            // 
            this.yoneticiDuzenleMenuStrip.ForeColor = System.Drawing.Color.White;
            this.yoneticiDuzenleMenuStrip.Name = "yoneticiDuzenleMenuStrip";
            this.yoneticiDuzenleMenuStrip.Size = new System.Drawing.Size(156, 24);
            this.yoneticiDuzenleMenuStrip.Text = "YÖNETİCİ DÜZENLE";
            this.yoneticiDuzenleMenuStrip.Click += new System.EventHandler(this.yoneticiDuzenleMenuStrip_Click);
            // 
            // kullaniciAyarMenuStrip
            // 
            this.kullaniciAyarMenuStrip.ForeColor = System.Drawing.Color.White;
            this.kullaniciAyarMenuStrip.Name = "kullaniciAyarMenuStrip";
            this.kullaniciAyarMenuStrip.Size = new System.Drawing.Size(164, 24);
            this.kullaniciAyarMenuStrip.Text = "KULLANICI AYARLARI";
            this.kullaniciAyarMenuStrip.Click += new System.EventHandler(this.kullaniciAyarMenuStrip_Click);
            // 
            // cikisMenuStrip
            // 
            this.cikisMenuStrip.ForeColor = System.Drawing.Color.White;
            this.cikisMenuStrip.Name = "cikisMenuStrip";
            this.cikisMenuStrip.Size = new System.Drawing.Size(55, 24);
            this.cikisMenuStrip.Text = "ÇIKIŞ";
            this.cikisMenuStrip.Click += new System.EventHandler(this.cikisMenuStrip_Click);
            // 
            // serverDuzen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(751, 410);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.silBtn);
            this.Controls.Add(this.guncelleBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "serverDuzen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Server Düzenleme Ekranı";
            this.Load += new System.EventHandler(this.serverDuzen_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox serverAdiGuncelTxt;
        private System.Windows.Forms.TextBox ipAdresGuncelTxt;
        private System.Windows.Forms.TextBox kulAdiGuncelTxt;
        private System.Windows.Forms.TextBox sifreGuncelTxt;
        private System.Windows.Forms.Button guncelleBtn;
        private System.Windows.Forms.Button silBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ServerEkleMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem serverDuzenleMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem yoneticiDuzenleMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem kullaniciAyarMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem cikisMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem anaSayfaMenuStrip;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
    }
}